<?php
	error_reporting(0);
	$image_dir = "./uploads/";
    $resultArray = array();
	$result = false;

	if($_POST){
		if (isset($_POST["fileRef"]) && $_POST["fileRef"] != "") {
			$filename = $image_dir.$_POST["fileRef"];
			if (unlink($filename)) {
				$resultArray["message"] = "Deleted sucessfully";
				$result = true;
			} else {
				$resultArray["message"] = "Couldn't able to delete the file";
				$result = false;
			}
		}
	}
	$resultArray["status"] = $result;
	echo json_encode($resultArray);
?>