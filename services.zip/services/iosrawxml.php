<?php

function getReportDirectory() {
	$fileExt = simplexml_load_file("../config/fileExtensionSupport.xml");
	$reportDirectory = $fileExt->xpath('//reportsPath');
	if ($reportDirectory) {
		$reportDirectory = $reportDirectory[0];
		if (!file_exists($reportDirectory)) {
			$flc = @mkdir($reportDirectory);
			if (!$flc) { return addResponse(false, "Please contact administrator. Invalid reports location."); }
		}
		if (!is_dir($reportDirectory) || !is_writable($reportDirectory)) { return addResponse(false, "Please contact administrator. Invalid reports location."); }
	} else return addResponse(false, "Please contact administrator. Check fileExtensionSupport.xml file.");
	
	return $reportDirectory;
}

function createXMLReport() {
	$reportDirectory = getReportDirectory();

	//if (!$reportDirectory) return false;
	
	$xmlData = fopen("php://input", "r");
	if ($xmlData === false || empty($xmlData)) return addResponse(false, "Please contact administrator. Invalid imput XML.");
	
	$reportTitle = "ios";
	$reportTitle .= '-' . md5(uniqid(rand())) . '-' . date("YmdHisu");
	$result = file_put_contents($reportDirectory.$reportTitle.".xml", $xmlData);
	if (!$result) return addResponse(false, "Please contact administrator. Couldn't able to write XML.");
	return addResponse(true, $reportTitle);
}

function addResponse($status, $message) {
	header('Content-Type: text/xml');
	if ($status) {
		echo "<response>
			<status>True</status>
			<fileRef>".($message ? $message : 'No File Reference')."</fileRef>
		</response>";
	} else {
		echo "<response>
			<status>False</status>
			<errorMessage>".($message ? $message : 'Error')."</errorMessage>
		</response>";
	}
	return $status;
}

function decrypt($ciphertext, $password) {
    $ciphertext = base64_decode($ciphertext);
    if (substr($ciphertext, 0, 8) != "Salted__") {
        return false;
    }
    $salt = substr($ciphertext, 8, 8);
    $keyAndIV = evpKDF($password, $salt);
    $decryptPassword = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, 
            $keyAndIV["key"], 
            substr($ciphertext, 16), 
            MCRYPT_MODE_CBC, 
            $keyAndIV["iv"]);
	return $decryptPassword;
}

function evpKDF($password, $salt, $keySize = 8, $ivSize = 4, $iterations = 1, $hashAlgorithm = "md5") {
    $targetKeySize = $keySize + $ivSize;
    $derivedBytes = "";
    $numberOfDerivedWords = 0;
    $block = NULL;
    $hasher = hash_init($hashAlgorithm);
    while ($numberOfDerivedWords < $targetKeySize) {
        if ($block != NULL) {
            hash_update($hasher, $block);
        }
        hash_update($hasher, $password);
        hash_update($hasher, $salt);
        $block = hash_final($hasher, TRUE);
        $hasher = hash_init($hashAlgorithm);

        // Iterations
        for ($i = 1; $i < $iterations; $i++) {
            hash_update($hasher, $block);
            $block = hash_final($hasher, TRUE);
            $hasher = hash_init($hashAlgorithm);
        }

        $derivedBytes .= substr($block, 0, min(strlen($block), ($targetKeySize - $numberOfDerivedWords) * 4));

        $numberOfDerivedWords += strlen($block)/4;
    }

    return array(
        "key" => substr($derivedBytes, 0, $keySize * 4),
        "iv"  => substr($derivedBytes, $keySize * 4, $ivSize * 4)
    );
}

$timeFrame = "";
$totalTimeStamp = "";
$secretKey = "";
$fileExt = simplexml_load_file("../config/fileExtensionSupport.xml");
foreach($fileExt->xpath('//supportedfiles') as $item) { 
	$totalTimeStamp = $item->timeOut;
	$secretKey = $item->secretKey;
}

foreach (getallheaders() as $name => $value) {
	if($name === 'timeFrame') {
		$timeFrame = $value;
	}
}

$preTime = decrypt($timeFrame,$secretKey);

if((strtotime(str_replace("GMT"," ",substr(gmdate("Y-m-dTH:i:sZ"),0,21))) - strtotime(substr($preTime,0,18))) < $totalTimeStamp){	
	createXMLReport();
} else {
	header('X-PHP-Response-Code: 500', false, 500);
	return addResponse(false, "Request timeout");
}

?>
