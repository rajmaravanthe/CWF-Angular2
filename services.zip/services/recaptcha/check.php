<?php
if (!isset($_SESSION)) {
	session_start();
}

require_once ('recaptchalib.php');
$privatekey = "6LcFytgSAAAAAL2NYm4gHq1SlgYF3q4GBFjZ4Cs_";
$resp = recaptcha_check_answer($privatekey, $_SERVER["REMOTE_ADDR"], $_POST["challenge"], $_POST["response"]);
if (!$resp -> is_valid) {
	$_SESSION['recaptcha_valid'] = false;
	echo json_encode( array('status' => false) );
} else {
	$_SESSION['recaptcha_valid'] = true;
	echo json_encode( array('status' => true) );
}
?>