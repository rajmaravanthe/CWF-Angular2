<?php

$configDirectory = "../config/";
$uploadDirectory = "./uploads/";

function validateInput() {
	if (error_get_last() != null) { return array('status' => false, 'error' => "<b>Warning</b>: UPLOAD_LIMIT: POST Content-Length exceeds the limit"); }
	elseif (!isset($_POST)) { return array('status' => false, 'error' => "Please post the xml data"); }
	elseif (!isset($_POST['eventDetails'])) { return array('status' => false, 'error' => "Please provide valid event details"); }
	else { return array('status' => true); }
}

function printOutput($returnResult) {
	echo json_encode($returnResult);
	die();
}

function loadXMLFile($xmlFile) {
	global $configDirectory;
	$simpleXML = simplexml_load_file($configDirectory.$xmlFile.".xml");
	return $simpleXML;
}

function getXMLData($xmlFile, $xmlPath, $singleData = false) {
	if (!isset($GLOBALS['xmlData'][$xmlFile])) { $GLOBALS['xmlData'][$xmlFile] = loadXMLFile($xmlFile); }
	$currentXML = $GLOBALS['xmlData'][$xmlFile];
	$result = $currentXML->xpath($xmlPath);
	if ($singleData) return count($result) > 0 ? $result[0] : false;
	else return count($result) == 1 ? $result[0] : $result;
}

function encodeFile($fileName) {
	global $uploadDirectory;
	$filePath = $uploadDirectory.$fileName;
	$fileHandle = fopen($filePath, 'r');
	$fileBinary = fread($fileHandle, filesize($filePath));
	fclose($fileHandle);
	unset($filePath, $fileHandle);
	return base64_encode($fileBinary);
}

function getMIMEType($fileName) {
	global $uploadDirectory;
	$filePath = $uploadDirectory.$fileName;
    if (function_exists("finfo_open") && function_exists("finfo_file")) {
		$finfo = finfo_open(FILEINFO_MIME_TYPE); 
		$mime = finfo_file($finfo, $filePath);
		unset($finfo, $filePath, $fileName);
		return $mime;
    } else return "application/octet-stream";
}

function createChildElement($document = null, $parent = null, $elemObj, $attributes = array()) {
	if (!isset($document) || is_null($document)) return false;
	if (!isset($parent) || is_null($parent)) return false;
	
	$tempElement = false;
	if (is_string($elemObj)) {
		$tempElement = $document->createElement($elemObj);
	} elseif (is_array($elemObj) && isset($elemObj['ns'])) {
		$tempElement = $document->createElementNS($elemObj['ns'], $elemObj['tag'], (isset($elemObj['value']) ? htmlentities($elemObj['value']) : null));
	} elseif (is_array($elemObj)) {
		$tempElement = $document->createElement($elemObj['tag'], (isset($elemObj['value']) ? htmlentities($elemObj['value']) : null));
	}
	
	foreach ($attributes as $key => $attribute) {
		if ( is_array($attribute) && isset($attribute['ns']) ) {
			$tempElement->setAttributeNS( $attribute['p'], $attribute['ns'], $attribute['uri']);
		} else {
			$tempElement->setAttribute( $key, $attribute);
		}
	}
	if ($tempElement) {
		$parent->appendChild($tempElement);
	}
	return $tempElement;
}
function convert_smart_quotes($string){ 
    header('Content-type: text/html; charset=UTF-8'); 
	$additionalInformation = preg_replace('!\s+!', ' ', $string);
	//$additionalInformation = str_replace(array("~", "#", "$", "%", "^", "&", "*","(",")","@","_","+","=","!"),array("","","","","","","","","","","","","",""), $additionalInformation);
	//$additionalInformation = str_replace(array("~", "#", "$", "%", "^", "*","(",")","+","=","!"),array("","","","","","","","","",""), $additionalInformation);
	$additionalInformation = str_replace(array("amp;", "amp;."), array("",""), $additionalInformation);
	$additionalInformation = iconv('UTF-8', 'ISO-8859-1//TRANSLIT//IGNORE', $additionalInformation);
	$additionalInformation = iconv('UTF-8', 'Windows-1252//TRANSLIT//IGNORE', $additionalInformation);
	$additionalInformation = iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $additionalInformation);
	return $additionalInformation;
}
function createXMLReport() {

	$locationError = array('status' => false, 'error' => "Please contact administrator. Invalid reports location.");
	
	$reportDirectory = (string) getXMLData('fileExtensionSupport', '//reportsPath');
	if (!is_dir($reportDirectory)) {
		$flc = @mkdir($reportDirectory);
		if (!$flc) { return $locationError; }
	}
	if (!is_dir($reportDirectory) || !is_writable($reportDirectory)) { return $locationError; }
	
	$personalInfo = (isset($_POST['personalInfo'])) ? $_POST['personalInfo'] : false;
	$eventDetails = (isset($_POST['eventDetails'])) ? $_POST['eventDetails'] : false;
	$personsInvolved = (isset($_POST['personsInvolved'])) ? $_POST['personsInvolved'] : false;
	$vehiclesInvolved = (isset($_POST['vehiclesInvolved']) && isset($_POST['vehiclesInvolved']['vehicles']) && !empty($_POST['vehiclesInvolved']['vehicles'])) ? $_POST['vehiclesInvolved']['vehicles'] : false;
	$additionalInfo = (isset($_POST['additionalInfo'])) ? $_POST['additionalInfo'] : false;
	$attachmentsInfo = (isset($_POST['attachmentsInfo'])) ? $_POST['attachmentsInfo'] : false;
	
	$today = time();
	$reportTitle = "";
	$appendTime = date("YmdHisu");
	
	if ($personalInfo && trim($personalInfo['reporterName']) != "") { $reportTitle = $personalInfo['reporterName']; }
	else { $reportTitle = (string) getXMLData('aboutYourselfConfig', '//prefixreportname'); }
	$reportTitle .= '-' . md5(uniqid(rand())) . '-' . $appendTime;
	
	
	$xmlDoc = new DOMDocument('1.0', 'UTF-8');
	$xmlDoc->formatOutput = true;
	
	$doPublish = createChildElement( $xmlDoc, $xmlDoc, 'lexspd:doPublish', array(
		array( 'ns' => 'xmlns:xsi', 'uri' => 'http://www.w3.org/2001/XMLSchema-instance', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		//array( 'ns' => 'xsi:schemaLocation', 'uri' => 'http://usdoj.gov/leisp/lexs/publishdiscover/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:scr', 'uri' => 'http://niem.gov/niem/domains/screening/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexsdigest', 'uri' => 'http://usdoj.gov/leisp/lexs/digest/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:sari', 'uri' => 'http://ijis-isesar/1.5', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexspd', 'uri' => 'http://usdoj.gov/leisp/lexs/publishdiscover/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:j', 'uri' => 'http://niem.gov/niem/domains/jxdm/4.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexslib', 'uri' => 'http://usdoj.gov/leisp/lexs/library/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexs', 'uri' => 'http://usdoj.gov/leisp/lexs/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:s', 'uri' => 'http://niem.gov/niem/structures/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:it', 'uri' => 'http://niem.gov/niem/domains/internationalTrade/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:nc', 'uri' => 'http://niem.gov/niem/niem-core/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' )
	));
	
	$pubMessageContainer = createChildElement( $xmlDoc, $doPublish, 'lexs:PublishMessageContainer');
	$pubMessage = createChildElement( $xmlDoc, $pubMessageContainer, 'lexs:PublishMessage');
	
	$lexsMessageData = createChildElement( $xmlDoc, $pubMessage, array(
		'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
		'tag' => 'lexs:PDMessageMetadata'
	), array(
		array( 'ns' => 'xmlns:xsi', 'uri' => 'http://www.w3.org/2001/XMLSchema-instance', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:nc', 'uri' => 'http://niem.gov/niem/niem-core/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' )
	));
	createChildElement( $xmlDoc, $lexsMessageData, array(
		'tag' => 'lexs:LEXSVersion', 'value' => '3.1.2'
	));
	createChildElement( $xmlDoc, $lexsMessageData, array(
		'tag' => 'lexs:MessageDateTime', 'value' => date("c")
	));
	createChildElement( $xmlDoc, $lexsMessageData, array(
		'tag' => 'lexs:MessageSequenceNumber', 'value' => 1
	));
	
	$lexsSubmitterData = createChildElement( $xmlDoc, $pubMessage, array(
		'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
		'tag' => 'lexs:DataSubmitterMetadata'
	), array(
		array( 'ns' => 'xmlns:xsi', 'uri' => 'http://www.w3.org/2001/XMLSchema-instance', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:nc', 'uri' => 'http://niem.gov/niem/niem-core/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' )
	));
	$lexsSubmitterDataSI = createChildElement( $xmlDoc, $lexsSubmitterData, array(
		'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
		'tag' => 'lexs:SystemIdentifier'
	));
	createChildElement( $xmlDoc, $lexsSubmitterDataSI, array(
		'tag' => 'nc:OrganizationName', 'value' => 'WebForm'
	));
	createChildElement( $xmlDoc, $lexsSubmitterDataSI, array(
		'tag' => 'lexs:SystemID', 'value' => 'WebForm'
	));

	$lexsSubmitterDataSC = createChildElement( $xmlDoc, $lexsSubmitterData, array( 
		'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
		'tag' => 'lexs:SystemContact'
	));
	createChildElement( $xmlDoc, $lexsSubmitterDataSC, 'nc:PersonSurName', array(
		'xsi:nil' => 'true'
	));

	$lexsSubmitterDataSI = createChildElement( $xmlDoc, $lexsSubmitterData, array(
		'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
		'tag' => 'lexs:DomainAttribute'
	));
	createChildElement( $xmlDoc, $lexsSubmitterDataSI, array(
		'tag' => 'lexs:AttributeName', 'value' => 'ClientIPAddress'
	));
	createChildElement( $xmlDoc, $lexsSubmitterDataSI, array(
		'tag' => 'lexs:AttributeValue', 'value' => $_SERVER['REMOTE_ADDR']
	));
	createChildElement( $xmlDoc, $lexsSubmitterDataSI, array(
		'tag' => 'lexs:Domain', 'value' => 'SystemIdentification'
	));
	
	$lexsDataItemPackage = createChildElement( $xmlDoc, $pubMessage, array(
		'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
		'tag' => 'lexs:DataItemPackage'
	), array(
		array( 'ns' => 'xmlns:scr', 'uri' => 'http://niem.gov/niem/domains/screening/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexsdigest', 'uri' => 'http://usdoj.gov/leisp/lexs/digest/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:sari', 'uri' => 'http://ijis-isesar/1.5', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:sari11', 'uri' => 'http://ijis-isesar/1.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexspd', 'uri' => 'http://usdoj.gov/leisp/lexs/publishdiscover/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:j', 'uri' => 'http://niem.gov/niem/domains/jxdm/4.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexslib', 'uri' => 'http://usdoj.gov/leisp/lexs/library/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:lexs', 'uri' => 'http://usdoj.gov/leisp/lexs/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:s', 'uri' => 'http://niem.gov/niem/structures/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:it', 'uri' => 'http://niem.gov/niem/domains/internationalTrade/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' ),
		array( 'ns' => 'xmlns:nc', 'uri' => 'http://niem.gov/niem/niem-core/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' )
	));
	
	$pkgMD = createChildElement( $xmlDoc, $lexsDataItemPackage, array(
		'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
		'tag' => 'lexs:PackageMetadata'
	));
	createChildElement( $xmlDoc, $pkgMD, array(
		'tag' => 'lexs:DataItemID', 'value' => $reportTitle
	));
	createChildElement( $xmlDoc, $pkgMD, array(
	'tag' => 'lexs:DataItemDate', 'value' => date('Y-m-d')));
	
	createChildElement( $xmlDoc, $pkgMD, array('tag' => 'lexs:DataItemReferenceID') );
	
	createChildElement( $xmlDoc, $pkgMD, array(
		'tag' => 'lexs:DataItemStatus', 'value' => 'Submit'
	));
	$pkgMDOwner = createChildElement( $xmlDoc, $pkgMD, 'lexs:DataOwnerMetadata' );
	$pkgMDOwnerI = createChildElement( $xmlDoc, $pkgMDOwner, 'lexs:DataOwnerIdentifier' );
	createChildElement( $xmlDoc, $pkgMDOwnerI, array(
		'tag' => 'lexs:OriginatingAgencyID', 'value' => 'WebForm'
	));
	createChildElement( $xmlDoc, $pkgMDOwnerI, array(
		'tag' => 'nc:OrganizationName', 'value' => 'WebForm'
	));
	createChildElement( $xmlDoc, $pkgMDOwnerI, array(
		'tag' => 'lexs:SystemID', 'value' => 'WebForm'
	));
	$pkgMDOwnerC = createChildElement( $xmlDoc, $pkgMDOwner, 'lexs:DataOwnerContact' );
	createChildElement( $xmlDoc, $pkgMDOwnerC, 'nc:PersonSurName', array( 'xsi:nil' => 'true' ) );
	createChildElement( $xmlDoc, $pkgMD, array(
		'tag' => 'lexs:DisseminationCriteria', 'value' => 'white'
	));
	
	$lexsDigest = createChildElement( $xmlDoc, $lexsDataItemPackage, 'lexs:Digest' );
	/*
	 * Persons Invovled Entity
	 */
	$personDescription = "";
	if($eventDetails && $eventDetails['addInfoProvided'] == "Yes" && $personsInvolved) {
		foreach ($personsInvolved as $id => $personInfo) {
			if ($personInfo[0]=="SELECT" && $personInfo[1]=="SELECT" && empty($personInfo[2])
				&& empty($personInfo[3]) && $personInfo[4]=="SELECT" && $personInfo[5]=="SELECT"
				&& $personInfo[6]=="SELECT" && empty($personInfo[7]) && empty($personInfo[8])
				&& empty($personInfo[9])) {
					
				unset($personsInvolved[$id]);
			} else {
				$personEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityPerson' );
				$lexsPerson = createChildElement( $xmlDoc, $personEntity, 'lexsdigest:Person', array( 's:id' => 'LP-'.($id + 1) ) );
				if($personInfo[2]!=''){
					$tempEl_1 = createChildElement( $xmlDoc, $lexsPerson, 'nc:PersonAgeMeasure');
					createChildElement( $xmlDoc, $tempEl_1, array( 'tag' => 'nc:MeasurePointValue', 'value' => $personInfo[2]) );
				}
				$tempEl_1 = createChildElement( $xmlDoc, $lexsPerson, 'nc:PersonAlternateName');
				createChildElement( $xmlDoc, $tempEl_1, 'nc:PersonSurName', array( 'xsi:nil' => 'true' ) );
				createChildElement( $xmlDoc, $tempEl_1, array( 'tag' => 'nc:PersonFullName', 'value' => $personInfo[9] ) );
				$eyeCode = (string) getXMLData('personConfig', '//personeyecolor/eyecolor[@title="'.$personInfo[5].'"]/eyecolorcode');
				if($eyeCode != "") createChildElement( $xmlDoc, $lexsPerson, array( 'tag' => 'nc:PersonEyeColorCode', 'value' => $eyeCode ) );
				$hairCode = (string) getXMLData('personConfig', '//personhaircolor/haircolor[@title="'.$personInfo[6].'"]/haircolorcode');
				if($hairCode != "") createChildElement( $xmlDoc, $lexsPerson, array( 'tag' => 'nc:PersonHairColorCode', 'value' => $hairCode ) );
				if($personInfo[3]!=''){
					$tempEl_1 = createChildElement( $xmlDoc, $lexsPerson, 'nc:PersonHeightMeasure');
					createChildElement( $xmlDoc, $tempEl_1, array( 'tag' => 'nc:MeasurePointValue', 'value' => $personInfo[3]) );
				}
				$tempEl_1 = createChildElement( $xmlDoc, $lexsPerson, 'nc:PersonName');
				createChildElement( $xmlDoc, $tempEl_1, 'nc:PersonSurName', array( 'xsi:nil' => 'true' ) );
				createChildElement( $xmlDoc, $tempEl_1, array( 'tag' => 'nc:PersonFullName', 'value' => $personInfo[8] ) );
				
				$raceCode = (string) getXMLData('personConfig', '//personrace/racename[@title="'.$personInfo[0].'"]/racecode');
				if($raceCode != "") createChildElement( $xmlDoc, $lexsPerson, array( 'tag' => 'nc:PersonRaceCode', 'value' => $raceCode ) );
				$sexCode = ($personInfo[1] == "MALE") ? "M" :($personInfo[1] == "FEMALE" ? "F"  : "U");
				createChildElement( $xmlDoc, $lexsPerson, array( 'tag' => 'nc:PersonSexCode', 'value' => $sexCode ) );
				//$personName = ($personInfo[8] == "" && $personInfo[9] == "") ? ("person".($id + 1)) : ($personInfo[8]." ".$personInfo[9]);
				$personName = ($personInfo[8] == "" && $personInfo[9] == "") ? ("person".($id + 1)) : ($personInfo[8]);
				if (isset($personInfo[7]) && !empty($personInfo[7])) {
					$personDescription = (empty($personDescription) ? "" : " ") . "Additional Description for {$personName} : " . htmlentities($personInfo[7]);
				}
				$tempEl_1 = createChildElement( $xmlDoc, $personEntity, 'j:Subject', array( 's:id' => 'LS-'.($id+1) ) );
				createChildElement( $xmlDoc, $tempEl_1, 'nc:RoleOfPersonReference', array( 's:ref' => 'LP-'.($id+1) ) );
				unset($personEntity, $lexsPerson, $tempEl_1, $eyeCode, $hairCode, $raceCode, $sexCode, $personName);
			}
		}
		
	}
	if($personalInfo){
		$count = ($personsInvolved) ? count($personsInvolved) + 1 : 1;
		$personEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityPerson' );
		$lexsPerson = createChildElement( $xmlDoc, $personEntity, 'lexsdigest:Person', array( 's:id' => "LP-{$count}" ) );
		$tempEl_1 = createChildElement( $xmlDoc, $lexsPerson, 'nc:PersonName');
		createChildElement( $xmlDoc, $tempEl_1, 'nc:PersonSurName', array( 'xsi:nil' => 'true' ) );
		createChildElement( $xmlDoc, $tempEl_1, array( 'tag' => 'nc:PersonFullName', 'value' => (($personalInfo && trim($personalInfo['reporterName']) != "") ? trim($personalInfo['reporterName']) : "") ) );
		$tempEl_1 = createChildElement( $xmlDoc, $personEntity, 'j:Witness');
		createChildElement($xmlDoc, $tempEl_1, 'nc:RoleOfPersonReference', array( 's:ref' => "LP-{$count}" ) );
		unset($count, $personEntity, $lexsPerson, $tempEl_1);
	}

	/*
	 * Locations Entity
	 */
	 $locationEntityAdded = false;
	 if($eventDetails && !empty($eventDetails['map_address'])) {
	 	$locationEntityAdded = true;
		$locationEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityLocation', array( 's:id' => 'LLOC-1' ) );
		$locationEl = createChildElement( $xmlDoc, $locationEntity, 'nc:Location' );
		$locationAdd = createChildElement( $xmlDoc, $locationEl, 'nc:LocationAddress' );
		$locationAddS = createChildElement( $xmlDoc, $locationAdd, 'nc:StructuredAddress' );
		
		$mapAddress = $eventDetails['map_address'];
		$splitAddress = explode(',', $mapAddress);
		if (count($splitAddress) === 3) {
			$postCodeSplit = explode(' ', trim(array_pop($splitAddress)));
			$state = null; $zip = null;
			if (is_numeric($postCodeSplit[count($postCodeSplit) - 1])) {
				$zip = trim(array_pop($postCodeSplit));
				$state = implode(' ', $postCodeSplit);
			} else $state = implode(' ', $postCodeSplit);
			$locationAddSStreet = createChildElement( $xmlDoc, $locationAddS, 'nc:LocationStreet' );
			createChildElement( $xmlDoc, $locationAddSStreet, array( 'tag' => 'nc:StreetFullText', 'value' => trim($splitAddress[0]) ) );
			createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationCityName', 'value' => trim($splitAddress[1]) ) );
			if ($state) createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationStateName', 'value' => $state ) );
			createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationCountryName', 'value' => 'USA' ) );
			if ($zip) createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationPostalCode', 'value' => $zip ) );

		} else createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:AddressSecondaryUnitText', 'value' => $mapAddress ) );
		if(isset($eventDetails['map_latlon'])) {
			$geoCord = createChildElement( $xmlDoc, $locationEl, 'nc:LocationTwoDimensionalGeographicCoordinate' );
			$latP = createChildElement( $xmlDoc, $geoCord, 'nc:GeographicCoordinateLatitude' );
			createChildElement( $xmlDoc, $latP, array( 'tag' => 'nc:LatitudeDegreeValue', 'value' => $eventDetails['map_latlon']['lat'] ) );
			$lonP = createChildElement( $xmlDoc, $geoCord, 'nc:GeographicCoordinateLongitude' );
			createChildElement( $xmlDoc, $lonP, array( 'tag' => 'nc:LongitudeDegreeValue', 'value' => $eventDetails['map_latlon']['lon'] ) );
		}
		
		unset($mapAddress, $splitAddress, $postCodeSplit, $state, $zip, $locationEntity, $locationEl, $locationAdd,
				$locationAddS, $locationAddSStreet, $geoCord, $latP, $lonP);
	}
	
	if($personalInfo){
		$locationEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityLocation' , array( 's:id' => 'LLOC-'.($locationEntityAdded ? 2 : 1) ));
		$locationEl = createChildElement( $xmlDoc, $locationEntity, 'nc:Location' );
		$locationAdd = createChildElement( $xmlDoc, $locationEl, 'nc:LocationAddress' );
		$locationAddS = createChildElement( $xmlDoc, $locationAdd, 'nc:StructuredAddress' );
		$locationAddSStreet = createChildElement( $xmlDoc, $locationAddS, 'nc:LocationStreet' );
		createChildElement( $xmlDoc, $locationAddSStreet, array( 'tag' => 'nc:StreetFullText', 
			'value' => ($personalInfo && isset($personalInfo['address']) ? ( $personalInfo['address'] . (isset($personalInfo['addressLine2']) ? ", " . $personalInfo['addressLine2'] : "") ) :  "")
		));
		createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationCityName', 'value' => ($personalInfo && isset($personalInfo['addressCity']) ? $personalInfo['addressCity'] : "") ) );
		createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationStateName', 'value' => ($personalInfo && isset($personalInfo['addressState']) ? $personalInfo['addressState'] : "") ) );
		createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationCountryName', 'value' => 'US' ) );
		createChildElement( $xmlDoc, $locationAddS, array( 'tag' => 'nc:LocationPostalCode', 'value' => ($personalInfo && isset($personalInfo['addressZipCode']) ? $personalInfo['addressZipCode'] : "") ) );
		unset($locationEntity, $locationEl, $locationAdd, $locationAddS, $locationAddSStreet );
		
		/*
		 * Email Entity
		 */
		$emailEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityEmail');																
		createChildElement( $xmlDoc, $emailEntity, array('tag' => 'nc:ContactEmailID', 'value' => ($personalInfo ? htmlentities($personalInfo['email']) : "") ), array( 's:id' => 'EMAIL-1' ) );
		unset($emailEntity);
		
		/*
		 * Telephone Number Entity
		 */
		$telephoneEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityTelephoneNumber', array( 's:id' => 'TEL-1' ) );
		$telephoneEL = createChildElement( $xmlDoc, $telephoneEntity, 'lexsdigest:TelephoneNumber' );
		$telephoneELFull = createChildElement( $xmlDoc, $telephoneEL, 'nc:FullTelephoneNumber' );
		createChildElement( $xmlDoc, $telephoneELFull, array( 'tag' => 'nc:TelephoneNumberFullID', 'value' => ($personalInfo ? htmlentities($personalInfo['phoneNumber']) : "") ) );
		unset($telephoneEntity, $telephoneEL, $telephoneELFull);
	}
	
	/*
	 * Activity Entity
	 */
	$activityEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityActivity', array( 's:id' => 'LACT-1' ) );
	$activityEL = createChildElement( $xmlDoc, $activityEntity, 'nc:Activity' );
	createChildElement( $xmlDoc, $activityEL, array( 'tag' => 'nc:ActivityCategoryText', 'value' => 'Suspicious Activity' ) );
	$timeOfTheDay = "";
	if($eventDetails && $eventDetails['happen_details'] != "") {
		$activityDt = createChildElement( $xmlDoc, $activityEL, 'nc:ActivityDate' );
		$timeOfTheDay = $eventDetails['happen_details']."T";
		if ($eventDetails['ampm'] == "PM") {
			$timeOfTheDay .= ($eventDetails['timeOfDayMin'] == "12" ? "00" : ( (int) $eventDetails['timeOfDayMin'] + 12 ));
		} elseif ($eventDetails['ampm'] == "AM") {
			$timeOfTheDay .= $eventDetails['timeOfDayMin'];
		}
		$timeOfTheDay .= ":" . $eventDetails['timeOfDaySec'] . ":00";
		createChildElement( $xmlDoc, $activityDt, array( 'tag' => 'nc:DateTime', 'value' => $timeOfTheDay ) );
	}
	//createChildElement( $xmlDoc, $activityDt, array( 'tag' => 'nc:DateTime', 'value' => $timeOfTheDay ) );
	
	
	/**
	 * Additional Information
	 */
	$entireAddInfo = $eventDetails['isaw'];
	if (!empty($personDescription)) {
		$entireAddInfo .= (empty($entireAddInfo) ? "" : "\n\t\t\t") . $personDescription;
	}
	$entireAddInfo .= (empty($entireAddInfo) ? "" : "\n\t\t\t") . "Additional Information : {$additionalInfo}";
	createChildElement( $xmlDoc, $activityEL, array( 'tag' => 'nc:ActivityDescriptionText', 'value' => htmlentities($entireAddInfo) ) );
	unset($activityEntity, $activityEL, $activityDt, $timeOfTheDay);
	
	/*
	 * Vehicle Entity
	 */
	 if($vehiclesInvolved) {
		foreach ($vehiclesInvolved as $id => $vehicle) {
			$vechicleEntity = false; $lexsVehicle = false; $prefix = '';
			if ($vehicle['vesselType'] === 'road') {
				$vechicleEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityVehicle' );
				$lexsVehicle = createChildElement( $xmlDoc, $vechicleEntity, 'nc:Vehicle', array( 's:id' => 'LVEH-'.($id + 1) ) );
				$prefix = 'Vehicle';
			} elseif ($vehicle['vesselType'] === 'air') {
				$vechicleEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityAircraft', array( 's:id' => 'LVEH-'.($id + 1) ) );
				$lexsVehicle = createChildElement( $xmlDoc, $vechicleEntity, 'nc:Aircraft' );
				$prefix = 'Aircraft';
			} elseif ($vehicle['vesselType'] === 'water') {
				$vechicleEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:EntityVessel', array( 's:id' => 'LVEH-'.($id + 1) ) );
				$lexsVehicle = createChildElement( $xmlDoc, $vechicleEntity, 'nc:Vessel' );
				$prefix = 'Vessel';
			}
			if ($vechicleEntity && $lexsVehicle) {
				if (isset($vehicle['addInfo']) && !empty($vehicle['addInfo'])) createChildElement($xmlDoc, $lexsVehicle, array('tag' => 'nc:ItemDescriptionText', 'value' => convert_smart_quotes($vehicle['addInfo'])));
				$styleCode = false;
				if (isset($vehicle['style']) && !empty($vehicle['style'])) {
					$styleCode = getXMLData('vehicle', '//stylename[@title="'.$vehicle['style'].'"]/stylecode', true);
				} 
				if (isset($vehicle['type']) && !empty($vehicle['type'])) {
					createChildElement($xmlDoc, $lexsVehicle, array('tag' => 'nc:ItemCategoryText', 'value' => strtoupper($vehicle['type'])));
					if (!$styleCode) {
						if($vehicle['type'] == "sedan"){$styleCode="SD";}
						else if($vehicle['type'] == "suv"){$styleCode="UT";}
						else if($vehicle['type'] == "wagon"){$styleCode="SW";}
						else if($vehicle['type'] == "hatch"){$styleCode="HB";}
						else if($vehicle['type'] == "coupe"){$styleCode="CP";}
						else if($vehicle['type'] == "convertable"){$styleCode="CV";}
						else if($vehicle['type'] == "pickup"){$styleCode="PK";}
						else if($vehicle['type'] == "crossover"){$styleCode="UT";}
						else if($vehicle['type'] == "van/minivan"){$styleCode="VN";}
					}
				} else createChildElement( $xmlDoc, $lexsVehicle, 'nc:ItemCategoryText' );
				if (isset($vehicle['color']) && !empty($vehicle['color'])) createChildElement($xmlDoc, $lexsVehicle, array('tag' => 'nc:ItemColorDescriptionText', 'value' => $vehicle['color']));
				if (isset($vehicle['make']) && !empty($vehicle['make'])) createChildElement($xmlDoc, $lexsVehicle, array('tag' => 'nc:ItemMakeName', 'value' => $vehicle['make']));
				if (isset($vehicle['model']) && !empty($vehicle['model'])) createChildElement($xmlDoc, $lexsVehicle, array('tag' => 'nc:ItemModelName', 'value' => $vehicle['model']));
				if (isset($vehicle['year']) && !empty($vehicle['year'])) createChildElement($xmlDoc, $lexsVehicle, array('tag' => 'nc:ItemModelYearDate', 'value' => $vehicle['year']));
				if ($styleCode && (($prefix == "Vehicle") || ($prefix == "Vessel"))) createChildElement( $xmlDoc, $lexsVehicle, array( 'tag' => "nc:VehicleStyleCode", 'value' => $styleCode ) );
				if ((isset($vehicle['licenseNo']) && !empty($vehicle['licenseNo'])) || (isset($vehicle['regState']) && !empty($vehicle['regState']))) {
					$regInfo = createChildElement($xmlDoc, $lexsVehicle, 'nc:ConveyanceRegistrationPlateIdentification');
					if (isset($vehicle['licenseNo']) && !empty($vehicle['licenseNo'])) createChildElement($xmlDoc, $regInfo, array('tag' => 'nc:IdentificationID', 'value' => $vehicle['licenseNo']));
					if (isset($vehicle['regState']) && !empty($vehicle['regState'])) createChildElement($xmlDoc, $regInfo, array('tag' => 'nc:IdentificationJurisdictionText', 'value' => $vehicle['regState']));
				}
				$makeCode = false;
				if (isset($vehicle['make'])) {
					if ($prefix == "Vessel") {
						$makeCode = getXMLData('vehicle', '//vessel[@title="'.$vehicle['make'].'"]/vesselcode', true);
					} else {
						$makeCode = getXMLData('vehicle', '//make[@title="'.$vehicle['make'].'"]/makecode', true);
					}
				}
				if ($makeCode) createChildElement( $xmlDoc, $lexsVehicle, array( 'tag' => "nc:{$prefix}MakeCode", 'value' => (string) $makeCode ) );
				if ($vehicle['vesselType'] === 'water') {
					if(isset($makeCode) && isset($vehicle['make'])) $modelCode = getXMLData('vehicle', '//make[@title="'.$vehicle['make'].'"]', true);
				} else if(isset($makeCode) && isset($vehicle['model'])) $modelCode = getXMLData('vehicle', '//make[@title="'.$vehicle['make'].'"]/model[@title="'.$vehicle['model'].'"]/modelcode', true);
				if ($prefix != "Vessel") {
					if(isset($modelCode)) createChildElement( $xmlDoc, $lexsVehicle, array( 'tag' => "nc:{$prefix}ModelCode", 'value' => (string) $modelCode ) );
				}
				if ($styleCode && ($prefix == "Aircraft")) createChildElement( $xmlDoc, $lexsVehicle, array( 'tag' => "nc:{$prefix}StyleCode", 'value' => $styleCode ) );
			}
			unset($vechicleEntity, $lexsVehicle, $styleCode, $regInfo, $makeCode, $modelCode);
		}
	}
		
	/*
	 * Associations Entity
	 */
	$associationEntity = createChildElement( $xmlDoc, $lexsDigest, 'lexsdigest:Associations' );
	if($eventDetails && isset($eventDetails['map_address']) && !empty($eventDetails['map_address'])) {
		$activityLocAsso = createChildElement( $xmlDoc, $associationEntity, 'j:ActivityLocationAssociation' );
		createChildElement( $xmlDoc, $activityLocAsso, 'nc:ActivityReference', array( 's:ref' => 'LACT-1' ) );
		createChildElement( $xmlDoc, $activityLocAsso, 'nc:LocationReference', array( 's:ref' => 'LLOC-1' ) );
		unset($activityLocAsso);
	}
	if($eventDetails && $eventDetails['addInfoProvided'] == "Yes" && $attachmentsInfo) {
		foreach ($attachmentsInfo as $id => $_) {
			$attachmentAssoEntity = createChildElement( $xmlDoc, $associationEntity, 'lexsdigest:EntityAttachmentLinkAssociation' );
			createChildElement( $xmlDoc, $attachmentAssoEntity, 'lexsdigest:EntityReference', array( 's:ref' => 'LACT-1' ) );
			createChildElement( $xmlDoc, $attachmentAssoEntity, 'lexsdigest:AttachmentLinkReference', array( 's:ref' => 'LAT-ATT'.($id+1) ) );
			unset($attachmentAssoEntity);
		}
	}
	if($personalInfo){
		$count = ($personsInvolved) ? count($personsInvolved) + 1 : 1;
		$tempEnitity = createChildElement( $xmlDoc, $associationEntity, 'lexsdigest:EntityEmailAssociation' );
		createChildElement( $xmlDoc, $tempEnitity, 'nc:PersonReference', array( 's:ref' => "LP-{$count}" ) );
		createChildElement( $xmlDoc, $tempEnitity, 'lexsdigest:EmailIDReference', array( 's:ref' => "EMAIL-1" ) );
		$tempEnitity = createChildElement( $xmlDoc, $associationEntity, 'lexsdigest:EntityTelephoneNumberAssociation' );
		createChildElement( $xmlDoc, $tempEnitity, 'nc:PersonReference', array( 's:ref' => "LP-{$count}" ) );
		createChildElement( $xmlDoc, $tempEnitity, 'lexsdigest:TelephoneNumberReference', array( 's:ref' => "TEL-1" ) );
		$tempEnitity = createChildElement( $xmlDoc, $associationEntity, 'nc:PersonLocationAssociation' );
		createChildElement( $xmlDoc, $tempEnitity, 'nc:PersonReference', array( 's:ref' => "LP-{$count}" ) );
		createChildElement( $xmlDoc, $tempEnitity, 'nc:LocationReference', array( 's:ref' => 'LLOC-'.($locationEntityAdded ? 2 : 1 )) );
		unset($associationEntity, $attachmentAssoEntity, $tempEnitity, $count, $lexsDigest);
	}
	/*
	 * Structured Payload
	 */
	$structurePlayload = createChildElement( $xmlDoc, $lexsDataItemPackage, 'lexs:StructuredPayload', array( 's:id' => 'Payload1.5' ) );
	$structureMetaEl = createChildElement( $xmlDoc, $structurePlayload, 'lexs:StructuredPayloadMetadata' );
	createChildElement( $xmlDoc, $structureMetaEl, array( 'tag' => 'lexs:CommunityURI', 'value' => 'http://ijis-isesar/1.5' ) );
	createChildElement( $xmlDoc, $structureMetaEl, array( 'tag' => 'lexs:CommunityDescription', 'value' => 'SAR Community' ) );
	createChildElement( $xmlDoc, $structureMetaEl, array( 'tag' => 'lexs:CommunityVersion', 'value' => '1.5' ) );
	unset($structureMetaEl);
	$suspiciousAR = createChildElement( $xmlDoc, $structurePlayload, 'sari:SuspiciousActivityReport' );
	$suspiciousMeta = createChildElement( $xmlDoc, $suspiciousAR, 'sari:SARMetadata' );
	$sartitle = "";
	if($eventDetails && $eventDetails['isaw'] != "") {
		if (strlen($eventDetails['isaw']) > 30) {
			$sartitle = substr($eventDetails['isaw'], 0, 27) . "...";
		} else {
			$sartitle = $eventDetails['isaw'];
		}
	}
	createChildElement( $xmlDoc, $suspiciousMeta, array( 'tag' => 'nc:TearlineIndicator', 'value' => 'true' ) );
	createChildElement( $xmlDoc, $suspiciousMeta, array( 'tag' => 'sari:PrivacyInformationExistsIndicator', 'value' => 'true' ) );
	createChildElement( $xmlDoc, $suspiciousMeta, array( 'tag' => 'sari:SARTitle', 'value' => $sartitle ) );
	unset($suspiciousMeta, $sartitle);
	$suspiciousARData = createChildElement( $xmlDoc, $suspiciousAR, 'sari:SARData' );
	$tempEl_1 = createChildElement( $xmlDoc, $suspiciousARData, 'sari:SuspiciousActivity', array( 's:id' => 'SACT-1' ) );
	$tempEl_2 = createChildElement( $xmlDoc, $tempEl_1, 'sari:SuspiciousActivityAugmentation' );
	createChildElement( $xmlDoc, $tempEl_2, 'lexslib:SameAsDigestReference', array( 'lexslib:ref' => 'LACT-1' ) );
	$tempEl_1 = createChildElement( $xmlDoc, $suspiciousARData, 'sari:ObservationActivity', array( 's:id' => 'LOACT-1' ) );
	$tempEl_2 = createChildElement( $xmlDoc, $tempEl_1, 'sari:ObservationActivityAugmentation' );
	createChildElement( $xmlDoc, $tempEl_2, 'lexslib:SameAsDigestReference', array( 'lexslib:ref' => 'LACT-1' ) );
	createChildElement( $xmlDoc, $tempEl_2, array( 'tag' => 'sari:SuspiciousActivityText', 'value' => htmlentities($entireAddInfo)) );
	
	if($eventDetails && $eventDetails['addInfoProvided'] == "Yes") {
		if ($personsInvolved) {
			foreach ($personsInvolved as $id => $personInfo) {
				$tempEl_1 = createChildElement( $xmlDoc, $suspiciousARData, 'sari:Person', array( 's:id' => 'SPER-'.($id+1) ) );
				createChildElement( $xmlDoc, $tempEl_1, array( 'tag' => 'nc:PersonBuildText', 'value' => $personInfo[4] ) );
				$tempEl_2 = createChildElement( $xmlDoc, $tempEl_1, 'sari:PersonAugmentation' );
				createChildElement( $xmlDoc, $tempEl_2, 'lexslib:SameAsDigestReference', array( 'lexslib:ref' => 'LP-'.($id+1) ) );
			}
		}
	}
	if ($personalInfo) {
		$count = ($personsInvolved) ? count($personsInvolved) + 1 : 1;
		$tempEl_1 = createChildElement( $xmlDoc, $suspiciousARData, 'sari:Person', array( 's:id' => "SPER-{$count}" ) );
		$tempEl_2 = createChildElement( $xmlDoc, $tempEl_1, 'sari:PersonAugmentation' );
		createChildElement( $xmlDoc, $tempEl_2, 'lexslib:SameAsDigestReference', array( 'lexslib:ref' => "LP-{$count}" ) );
		unset($count);
	}
	if($eventDetails && $eventDetails['map_address'] != ""){
		$tempEl_1 = createChildElement( $xmlDoc, $suspiciousARData, 'sari:Location', array( 's:id' => 'SLOC-1' ) );
		$tempEl_2 = createChildElement( $xmlDoc, $tempEl_1, 'sari:LocationAugmentation' );
		createChildElement( $xmlDoc, $tempEl_2, 'lexslib:SameAsDigestReference', array( 'lexslib:ref' => 'LLOC-1' ) );
	}
	if ($personalInfo) {
		$tempEl_1 = createChildElement( $xmlDoc, $suspiciousARData, 'sari:Location', array( 's:id' => 'SLOC-'.($locationEntityAdded ? 2 : 1) ) );
		$tempEl_2 = createChildElement( $xmlDoc, $tempEl_1, 'sari:LocationAugmentation' );
		createChildElement( $xmlDoc, $tempEl_2, 'lexslib:SameAsDigestReference', array( 'lexslib:ref' => 'LLOC-'.($locationEntityAdded ? 2 : 1) ) );
	}
	if($eventDetails && $eventDetails['addInfoProvided'] == "Yes" && $vehiclesInvolved) {
		foreach ($vehiclesInvolved as $id => $vehicle) {
			if ($vehicle['vesselType'] === 'road') {
				$vechicleEntity = createChildElement( $xmlDoc, $suspiciousARData, 'sari:Vehicle', array( 's:id' => 'LEXS-VEH'.($id+1) ) );
				$prefix = 'Vehicle';
			} elseif ($vehicle['vesselType'] === 'air') {
				$vechicleEntity = createChildElement( $xmlDoc, $suspiciousARData, 'sari:Aircraft', array( 's:id' => 'LEXS-AIR'.($id + 1) ) );
				$prefix = 'Aircraft';
			} elseif ($vehicle['vesselType'] === 'water') {
				$vechicleEntity = createChildElement( $xmlDoc, $suspiciousARData, 'sari:Vessel', array( 's:id' => 'LEXS-VES'.($id + 1) ) );
				$prefix = 'Vessel';
			}
			$tempEl_2 = createChildElement( $xmlDoc, $vechicleEntity,  "sari:{$prefix}Augmentation");
			createChildElement( $xmlDoc, $tempEl_2, 'lexslib:SameAsDigestReference', array( 'lexslib:ref' => 'LVEH-'.($id+1) ) );
		}
	}
	unset($suspiciousARData, $suspiciousAR, $tempEl_1, $tempEl_2, $structurePlayload,$additionalInfo,$iSawDescription,$entireAddInfo,$additionalInformation,$personDescription);
	
	/*
	 * Attachment Links && LEXS Attachment Entity Data
	 */
	if($eventDetails && $eventDetails['addInfoProvided'] == "Yes" && $attachmentsInfo) {
		foreach ($attachmentsInfo as $id => $attachInfo) {
			$attachLinkEl = createChildElement( $xmlDoc, $lexsDataItemPackage, 'lexs:AttachmentLink', array( 's:id' => 'LAT-ATT'.($id+1) ) );
			$attURI = createChildElement( $xmlDoc, $attachLinkEl, array( 'tag' => 'lexs:AttachmentURI', 'value' => 'services/uploads/'.$attachInfo['reference'] ) );
			createChildElement( $xmlDoc, $attachLinkEl, array( 'tag' => 'lexs:AttachmentViewableIndicator', 'value' => 'true' ) );
			createChildElement( $xmlDoc, $attachLinkEl, 'nc:BinaryDescriptionText', array( 'xsi:nil' => 'true' ) );
			createChildElement( $xmlDoc, $attachLinkEl, array( 'tag' => 'nc:BinarySizeValue', 'value' => $attachInfo['fileSizeB'] ) );
			createChildElement( $xmlDoc, $attachLinkEl, array( 'tag' => 'nc:BinaryCategoryText', 'value' => 'Image' ) );
			unset($attachLinkEl);
			
			$attachmentEl = createChildElement( $xmlDoc, $pubMessage, array(
				'ns' => 'http://usdoj.gov/leisp/lexs/3.1',
				'tag' => 'lexs:Attachment'
			), array(
				array( 'ns' => 'xmlns:lexs', 'uri' => 'http://usdoj.gov/leisp/lexs/3.1', 'p' => 'http://www.w3.org/2000/xmlns/' ),
				array( 'ns' => 'xmlns:nc', 'uri' => 'http://niem.gov/niem/niem-core/2.0', 'p' => 'http://www.w3.org/2000/xmlns/' ) 
			));
			$attachmentEl->appendChild( $attURI->cloneNode(true) );
			$attachmentBinary = createChildElement( $xmlDoc, $attachmentEl, 'nc:Binary' );
			createChildElement( $xmlDoc, $attachmentBinary, array( 'tag' => 'nc:BinaryID', 'value' => $attachInfo['reference'] ) );
			createChildElement( $xmlDoc, $attachmentBinary, array( 'tag' => 'nc:BinaryBase64Object', 'value' => encodeFile($attachInfo['reference']) ) );
			createChildElement( $xmlDoc, $attachmentBinary, array( 'tag' => 'nc:BinaryFormatID', 'value' => getMIMEType($attachInfo['reference']) ) );
			createChildElement( $xmlDoc, $attachmentBinary, array( 'tag' => 'nc:BinaryFormatStandardName', 'value' => 'MIME' ) );
			createChildElement( $xmlDoc, $attachmentBinary, array( 'tag' => 'nc:BinarySizeValue', 'value' => $attachInfo['fileSizeB'] ) );
			createChildElement( $xmlDoc, $attachmentBinary, 'nc:BinaryCategoryText' );
			unset($attachLinkEl, $attachmentBinary);
		}
	}
	
	$result = $xmlDoc->save($reportDirectory.$reportTitle.".xml");
	if ($result) {
		return array('status' => true, 'message' => "Success", 'reference' => $reportTitle, 'fileSize' => $result );
	} else return array('status' => false, 'error' => "Error occured while writing xml to file. Please contact administrator.");
}
function decrypt($cipherTextHex, $saltHex) {
	$keyAndIV = evpKDF("MySecretKey", hex2bin($saltHex));
	$decryptPassword = mcrypt_decrypt(MCRYPT_RIJNDAEL_128, 
        $keyAndIV["key"], 
        hex2bin($cipherTextHex), 
        MCRYPT_MODE_CBC, 
        $keyAndIV["iv"]);
	return $decryptPassword;
}
function evpKDF($password, $salt, $keySize = 8, $ivSize = 4, $iterations = 1, $hashAlgorithm = "md5") {
    $targetKeySize = $keySize + $ivSize;
    $derivedBytes = "";
    $numberOfDerivedWords = 0;
    $block = NULL;
    $hasher = hash_init($hashAlgorithm);
    while ($numberOfDerivedWords < $targetKeySize) {
        if ($block != NULL) {
            hash_update($hasher, $block);
        }
        hash_update($hasher, $password);
        hash_update($hasher, $salt);
        $block = hash_final($hasher, TRUE);
        $hasher = hash_init($hashAlgorithm);

        // Iterations
        for ($i = 1; $i < $iterations; $i++) {
            hash_update($hasher, $block);
            $block = hash_final($hasher, TRUE);
            $hasher = hash_init($hashAlgorithm);
        }

        $derivedBytes .= substr($block, 0, min(strlen($block), ($targetKeySize - $numberOfDerivedWords) * 4));

        $numberOfDerivedWords += strlen($block)/4;
    }

    return array(
        "key" => substr($derivedBytes, 0, $keySize * 4),
        "iv"  => substr($derivedBytes, $keySize * 4, $ivSize * 4)
    );
}
$result = validateInput();
if ($result['status'] == false) { printOutput($result); }
else {
	printOutput(createXMLReport());
	/*$preTime = decrypt($_POST['cipherTextHex'],$_POST['saltHex']);

	if((strtotime(str_replace("GMT"," ",substr(gmdate("Y-m-dTH:i:sZ"),0,21))) - strtotime(substr($preTime,0,18))) < 320){
		printOutput(createXMLReport());
	} else {
		printOutput(array('status' => false, 'message' => 'Timeout', 'error' => "Request timeout"));
	}*/
}

?>