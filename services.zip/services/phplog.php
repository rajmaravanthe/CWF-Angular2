<?php

$file=getPath();
switch ($_GET["method"]){
	case "home":
		write_log('Enter to citizen web forum.',$file);
		break;
	case "step1LoadPersonInvolved":
		write_log('Navigate Activity page to Person Involvement Page.',$file);
		break;
	case "step1VehicleInvolvement":
		write_log('Navigate Activity page to Vehicle Involvement Page.',$file);
		break;
	case "step1AdditionalInfo":
		write_log('Navigate Activity page to Additional Information Page.',$file);
		break;
	case "step1Upload":
		write_log('Navigate Activity page to Upload Details Page.',$file);
		break;
	case "step1Submit":
		write_log('Report Submited.',$file);
		break;
	case "personLoadVehicleInvolved":
		write_log('Navigate Person involvement page to Vehicle Involvement Page',$file);
		break;
	case "personLoadAddInfo":
		write_log('Navigate Person involvement page to Additional Information Page',$file);
		break;
	case "personLoadUpload":
		write_log('Navigate Person involvement page to Upload Page',$file);
		break;
	case "personLoadReturnHome":
		write_log('Navigate Person involvement page to Home Page',$file);
		break;
	case "personLoadCancel":
		write_log('Cancel and Navigate Person involvement page to Home Page',$file);
		break;
	case "personLoadAddPerson":
		write_log('One More Person added.',$file);
		break;
	case "personLoadSubmit":
		write_log('Person report submited, return to Activity Page.',$file);
		break;
	case "personLoadRemove":
		write_log('Remove a Existing Person.',$file);
		break;
	case "vehicleLoadPersonInvolved":
		write_log('Navigate Vehicle involvement page to Person Involvement Page',$file);
		break;
	case "vehicleLoadAddtionalInfo":
		write_log('Navigate Vehicle involvement page to Additional Information Page',$file);
		break;
	case "vehicleLoadUpload":
		write_log('Navigate Vehicle involvement page to Upload Page',$file);
		break;
	case "vehicleLoadReturnHome":
		write_log('Navigate Vehicle involvement page to Home Page',$file);
		break;
	case "vehicleLoadCancelReport":
		write_log('Cancel the Report and Navigate Vehicle involvement page to Home Page',$file);
		break;
	case "vehicleLoadAddVehicle":
		write_log('One More Vehicle added.',$file);
		break;
	case "vehicleLoadSubmitReport":
		write_log('Vehicle report submited, return to Activity Page.',$file);
		break;
	case "vehicleLoadRemove":
		write_log('Remove a Existing Vehicle.',$file);
		break;
	case "AddInfoLoadPersonInvolved":
		write_log('Navigate Additional Information page to Person Involvement Page',$file);
		break;
	case "AddInfoLoadVehicleInvolved":
		write_log('Navigate Additional Information page to Vehicle Involvement Page',$file);
		break;
	case "AddInfoLoadUpload":
		write_log('Navigate Additional Information page to Upload Page',$file);
		break;
	case "AddInfoLoadReturnHome":
		write_log('Navigate Additional Information page to Home Page',$file);
		break;
	case "AddInfoLoadCancelReport":
		write_log('Cancel the Report and Navigate Additional Information page to Home Page',$file);
		break;
	case "AddInfoLoadSubmitReport":
		write_log('Vehicle report submited, return to Activity Page.',$file);
		break;
	case "UploadPersonInvolvement":
		write_log('Navigate Upload page to Person Involvement Page',$file);
		break;
	case "UploadVehicleInvolvement":
		write_log('Navigate Upload page to Vehicle Involvement Page',$file);
		break;
	case "UploadAdditionalInfo":
		write_log('Navigate Upload page to Additional Information Page',$file);
		break;
	case "UploadReturnHome":
		write_log('Navigate Upload page to Home Page',$file);
		break;
	case "UploadCancelReport":
		write_log('Cancel the Report and Navigate Upload page to Home Page',$file);
		break;
	case "UploadSubmitReport":
		write_log('Vehicle report submited, return to Activity Page.',$file);
		break;
	case "logMessage":
		write_log($_REQUEST['msg'] ,$file);
		break;
	default:
		$returnResult["error"] = "Provide valid method name";
}


function getPath() {
	$path="logs/default.log";
	if(file_exists($path)) return $path;
	else return "logfile.log";
}

function write_log($message, $logfile) {
	if($logfile == '') {
		error_log('No log file defined!', 0);
        return array('status' => false, 'message' => 'No log file defined!');
	}
	
	if( ($time = $_SERVER['REQUEST_TIME']) == '') $time = time();
	if( ($remote_addr = $_SERVER['REMOTE_ADDR']) == '') $remote_addr = "REMOTE_ADDR_UNKNOWN";
	if( ($request_uri = $_SERVER['REQUEST_URI']) == '') $request_uri = "REQUEST_URI_UNKNOWN";
	$date = date("Y-m-d H:i:s", $time);
	
	if($fd = @fopen($logfile, "a+")) {
		$newLine="\r\n";
		$writemessage=$remote_addr." | ".$date." | ".$message;
		$result = @fwrite($fd, $writemessage . "\r\n");
		fclose($fd);
		
		if($result > 0) return array('status' => true);  
		else return array('status' => false, 'message' => 'Unable to write to '.$logfile.'!');
	} else return array('status' => false, 'message' => 'Unable to open log '.$logfile.'!');
}

?>